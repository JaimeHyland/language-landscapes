  <article>
    <?php echo $this->element($this->Session->read('Config.language').'/translation_issues'); ?>
  </article>