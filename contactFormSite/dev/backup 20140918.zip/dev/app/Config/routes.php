<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different urls to chosen controllers and their actions (functions).
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 * its action called 'display', and we pass a param to select the view file
 * to use (in this case, /app/View/Pages/home.ctp)...
 */
	Router::connect('/:language/:controller/:action/*', array(), array('language' => '[a-z]{3}'));
	Router::connect('/:language/:controller', array('action' => 'home'), array('language' => '[a-z]{3}'));
	Router::connect('/:language/', array('controller' => 'page', 'action' => 'home'), array('language' => '[a-z]{3}'));
	Router::connect('/', array('controller' => 'page', 'action' => 'home', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/home', array('controller' => 'page', 'action' => 'home', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/translation', array('controller' => 'page', 'action' => 'translation', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/quality', array('controller' => 'page', 'action' => 'quality', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/workflows_and_tools', array('controller' => 'page', 'action' => 'workflows_and_tools', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/web_localization', array('controller' => 'page', 'action' => 'web_localization', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/software_localization', array('controller' => 'page', 'action' => 'software_localization', array('language'=>'[a-z]{3}')));
	Router::connect('/page/:language/work_with_us', array('controller' => 'page', 'action' => 'work_with_us', array('language'=>'[a-z]{3}')));

/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();

/**
 * Load the CakePHP default routes. Only remove this if you do not want to use
 * the built-in default routes.
 */
	require CAKE . 'Config' . DS . 'routes.php';
