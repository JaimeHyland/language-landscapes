<?php echo $result; ?>
